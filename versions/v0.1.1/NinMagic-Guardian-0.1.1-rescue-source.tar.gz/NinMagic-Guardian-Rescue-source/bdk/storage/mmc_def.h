/*
 * Header for MultiMediaCard (MMC)
 *
 * Copyright 2002 Hewlett-Packard Company
 * Copyright 2018-2026 CTCaer
 *
 * Use consistent with the GNU GPL is permitted,
 * provided that this copyright notice is
 * preserved in its entirety in all copies and derived works.
 *
 * HEWLETT-PACKARD COMPANY MAKES NO WARRANTIES, EXPRESSED OR IMPLIED,
 * AS TO THE USEFULNESS OR CORRECTNESS OF THIS CODE OR ITS
 * FITNESS FOR ANY PARTICULAR PURPOSE.
 *
 * Many thanks to Alessandro Rubini and Jonathan Corbet!
 *
 * Based strongly on code by:
 *
 * Author: Yong-iL Joh <tolkien@mizi.com>
 *
 * Author:  Andrew Christian
 *          15 May 2002
 */

#ifndef MMC_H
#define MMC_H

/* Standard MMC commands (4.1)           type  argument     response */
/* class 1 */
#define MMC_GO_IDLE_STATE         0   /* bc                          */
#define MMC_SEND_OP_COND          1   /* bcr  [31:0] OCR         R3  */
#define MMC_ALL_SEND_CID          2   /* bcr                     R2  */
#define MMC_SET_RELATIVE_ADDR     3   /* ac   [31:16] RCA        R1  */
#define MMC_SET_DSR               4   /* bc   [31:16] RCA            */
#define MMC_SLEEP_AWAKE           5   /* ac   [31:16] RCA 15:flg R1b */
#define MMC_SWITCH                6   /* ac   [31:0] See below   R1b */
#define MMC_SELECT_CARD           7   /* ac   [31:16] RCA        R1  */
#define MMC_SEND_EXT_CSD          8   /* adtc                    R1  */
#define MMC_SEND_CSD              9   /* ac   [31:16] RCA        R2  */
#define MMC_SEND_CID             10   /* ac   [31:16] RCA        R2  */
#define MMC_READ_DAT_UNTIL_STOP  11   /* adtc [31:0] dadr        R1  */
#define MMC_STOP_TRANSMISSION    12   /* ac                      R1b */
#define MMC_SEND_STATUS          13   /* ac   [31:16] RCA        R1  */
#define MMC_BUS_TEST_R           14   /* adtc                    R1  */
#define MMC_GO_INACTIVE_STATE    15   /* ac   [31:16] RCA            */
#define MMC_BUS_TEST_W           19   /* adtc                    R1  */

/* class 2 */
#define MMC_SET_BLOCKLEN         16   /* ac   [31:0] block len   R1  */
#define MMC_READ_SINGLE_BLOCK    17   /* adtc [31:0] data addr   R1  */
#define MMC_READ_MULTIPLE_BLOCK  18   /* adtc [31:0] data addr   R1  */
#define MMC_SEND_TUNING_BLOCK_HS200 21 /* adtc R1  */

/* class 3 */
#define MMC_WRITE_DAT_UNTIL_STOP 20   /* adtc [31:0] data addr   R1  */

/* class 4 */
#define MMC_SET_BLOCK_COUNT      23   /* adtc [31:0] data addr   R1  */
#define MMC_WRITE_BLOCK          24   /* adtc [31:0] data addr   R1  */
#define MMC_WRITE_MULTIPLE_BLOCK 25   /* adtc                    R1  */
#define MMC_PROGRAM_CID          26   /* adtc                    R1  */
#define MMC_PROGRAM_CSD          27   /* adtc                    R1  */
#define MMC_SET_TIME             49   /* adtc                    R1  */

/* class 6 */
#define MMC_SET_WRITE_PROT       28   /* ac   [31:0] data addr   R1b */
#define MMC_CLR_WRITE_PROT       29   /* ac   [31:0] data addr   R1b */
#define MMC_SEND_WRITE_PROT      30   /* adtc [31:0] wpdata addr R1  */
#define MMC_SEND_WR_PROTECT_TYPE 31   /* adtc [31:0] wpdata addr R1  */

/* class 5 */
#define MMC_ERASE_GROUP_START    35   /* ac   [31:0] data addr   R1  */
#define MMC_ERASE_GROUP_END      36   /* ac   [31:0] data addr   R1  */
#define MMC_ERASE                38   /* ac                      R1b */

/* class 9 */
#define MMC_FAST_IO              39   /* ac   <Complex>          R4  */
#define MMC_GO_IRQ_STATE         40   /* bcr                     R5  */

/* class 7 */
#define MMC_LOCK_UNLOCK          42   /* adtc                    R1b */

/* class 8 */
#define MMC_APP_CMD              55   /* ac   [31:16] RCA        R1  */
#define MMC_GEN_CMD              56   /* adtc [0] RD/WR          R1  */

/* class 10 */
#define MMC_PROTOCOL_RD          53   /* adtc                    R1  */
#define MMC_PROTOCOL_WR          54   /* adtc                    R1  */

/* class 11 */
#define MMC_QUEUED_TASK_PARAMS   44   /* ac   [20:16] task id    R1  */
#define MMC_QUEUED_TASK_ADDR     45   /* ac   [31:0] data addr   R1  */
#define MMC_EXECUTE_READ_TASK    46   /* adtc [20:16] task id    R1  */
#define MMC_EXECUTE_WRITE_TASK   47   /* adtc [20:16] task id    R1  */
#define MMC_CMDQ_TASK_MGMT       48   /* ac   [20:16] task id    R1b */

/* class 12 */
#define MMC_VENDOR_CMD_60        60   /* Vendor Defined              */
#define MMC_VENDOR_CMD_61        61   /* Vendor Defined              */
#define MMC_VENDOR_CMD_62        62   /* Vendor Defined              */
#define MMC_VENDOR_CMD_63        63   /* Vendor Defined              */

/*
 * MMC_SWITCH argument format:
 *
 * [31:26] Always 0
 * [25:24] Access Mode
 * [23:16] Location of target Byte in EXT_CSD
 * [15:08] Value Byte
 * [07:03] Always 0
 * [02:00] Command Set
 */

/*
 * MMC status in R1, for native mode (SPI bits are different)
 * Type
 * e : error bit
 * s : status bit
 * r : detected and set for the actual command response
 * x : detected and set during command execution. the host must poll
 *     the card by sending status command in order to read these bits.
 * Clear condition
 * a : according to the card state
 * b : always related to the previous command. Reception of a valid
 *     command will clear it (with a delay of one command)
 * c : clear by read
*/

#define R1_OUT_OF_RANGE       (1 << 31) /* er, c */
#define R1_ADDRESS_ERROR      (1 << 30) /* erx, c */
#define R1_BLOCK_LEN_ERROR    (1 << 29) /* er, c */
#define R1_ERASE_SEQ_ERROR    (1 << 28) /* er, c */
#define R1_ERASE_PARAM        (1 << 27) /* ex, c */
#define R1_WP_VIOLATION       (1 << 26) /* erx, c */
#define R1_CARD_IS_LOCKED     (1 << 25) /* sx, a */
#define R1_LOCK_UNLOCK_FAILED (1 << 24) /* erx, c */
#define R1_COM_CRC_ERROR      (1 << 23) /* er, b */
#define R1_ILLEGAL_COMMAND    (1 << 22) /* er, b */
#define R1_CARD_ECC_FAILED    (1 << 21) /* ex, c */
#define R1_CC_ERROR           (1 << 20) /* erx, c */
#define R1_ERROR              (1 << 19) /* erx, c */
#define R1_UNDERRUN           (1 << 18) /* ex, c */
#define R1_OVERRUN            (1 << 17) /* ex, c */
#define R1_CID_CSD_OVERWRITE  (1 << 16) /* erx, c, CID/CSD overwrite */
#define R1_WP_ERASE_SKIP      (1 << 15) /* sx, c */
#define R1_CARD_ECC_DISABLED  (1 << 14) /* sx, a */
#define R1_ERASE_RESET        (1 << 13) /* sr, c */
#define R1_STATUS(x)          ((x) & 0xFFFFE000)
#define R1_CURRENT_STATE(x)   (((x) & 0x00001E00) >> 9) /* sx, b (4 bits) */
#define R1_READY_FOR_DATA     (1 << 8) /* sx, a */
#define R1_SWITCH_ERROR       (1 << 7) /* sx, c */
#define R1_EXCEPTION_EVENT    (1 << 6) /* sr, a */
#define R1_APP_CMD            (1 << 5) /* sr, c */
#define R1_SKIP_STATE_CHECK   (1 << 4) /* Custom state to skip expected state check */
#define R1_AKE_SEQ_ERROR      (1 << 3)

/* R1_CURRENT_STATE 12:9 */
#define R1_STATE(x)    ((x) << 9)
#define R1_STATE_IDLE  0
#define R1_STATE_READY 1
#define R1_STATE_IDENT 2
#define R1_STATE_STBY  3
#define R1_STATE_TRAN  4
#define R1_STATE_DATA  5
#define R1_STATE_RCV   6
#define R1_STATE_PRG   7
#define R1_STATE_DIS   8

/*
 * OCR bits are mostly in host.h
 */
#define MMC_OCR_VCCQ_18    (1 << 7)     /* Card VDD voltage 1.8 */
#define MMC_OCR_VCCQ_20_26 (0x7F << 8)  /* Card VDD voltage 2.0 ~ 2.6 */
#define MMC_OCR_VCCQ_27_34 (0x7F << 15) /* Card VDD voltage 2.7 ~ 3.4 */
#define MMC_OCR_HCS        (2 << 29)    /* Host Capacity status bit */
#define MMC_OCR_CCS        MMC_OCR_HCS  /* Card Capacity status bit */
#define MMC_OCR_BUSY       (1 << 31)    /* Card Power up status bit */

/*
 * Card Command Classes (CCC)
 */
#define CCC_BASIC        (1<<0)  /* (0) Basic protocol functions */
/* (CMD0,1,2,3,4,7,9,10,12,13,15) */
/* (and for SPI, CMD58,59) */
#define CCC_STREAM_READ  (1<<1)  /* (1) Stream read commands */
/* (CMD11) */
#define CCC_BLOCK_READ   (1<<2)  /* (2) Block read commands */
/* (CMD16,17,18) */
#define CCC_STREAM_WRITE (1<<3)  /* (3) Stream write commands */
/* (CMD20) */
#define CCC_BLOCK_WRITE  (1<<4)  /* (4) Block write commands */
/* (CMD16,24,25,26,27) */
#define CCC_ERASE        (1<<5)  /* (5) Ability to erase blocks */
/* (CMD32,33,34,35,36,37,38,39) */
#define CCC_WRITE_PROT   (1<<6)  /* (6) Able to write protect blocks */
/* (CMD28,29,30) */
#define CCC_LOCK_CARD    (1<<7)  /* (7) Able to lock down card */
/* (CMD16,CMD42) */
#define CCC_APP_SPEC     (1<<8)  /* (8) Application specific */
/* (CMD55,56,57,ACMD*) */
#define CCC_IO_MODE      (1<<9)  /* (9) I/O mode */
/* (CMD5,39,40,52,53) */
#define CCC_SWITCH       (1<<10) /* (10) High speed switch */
/* (CMD6,34,35,36,37,50) */
/* (11) Reserved */
/* (CMD?) */

/*
 * CSD field definitions
 */

#define CSD_STRUCT_VER_1_0 0 /* Valid for system specification 1.0 - 1.2 */
#define CSD_STRUCT_VER_1_1 1 /* Valid for system specification 1.4 - 2.2 */
#define CSD_STRUCT_VER_1_2 2 /* Valid for system specification 3.1 - 3.2 - 3.31 - 4.0 - 4.1 */
#define CSD_STRUCT_EXT_CSD 3 /* Version is coded in CSD_STRUCTURE in EXT_CSD */

#define CSD_SPEC_VER_0     0 /* Implements system specification 1.0 - 1.2 */
#define CSD_SPEC_VER_1     1 /* Implements system specification 1.4 */
#define CSD_SPEC_VER_2     2 /* Implements system specification 2.0 - 2.2 */
#define CSD_SPEC_VER_3     3 /* Implements system specification 3.1 - 3.2 - 3.31 */
#define CSD_SPEC_VER_4     4 /* Implements system specification 4.0 - 4.1 */

/*
 * EXT_CSD fields
 */

#define EXT_CSD_CMDQ_MODE_EN                 15 /* R/W */
#define EXT_CSD_FLUSH_CACHE                  32 /* W */
#define EXT_CSD_CACHE_CTRL                   33 /* R/W */
#define EXT_CSD_POWER_OFF_NOTIFICATION       34 /* R/W */
#define EXT_CSD_PACKED_FAILURE_INDEX         35 /* RO */
#define EXT_CSD_PACKED_CMD_STATUS            36 /* RO */
#define EXT_CSD_EXP_EVENTS_STATUS            54 /* RO, 2 bytes */
#define EXT_CSD_EXP_EVENTS_CTRL              56 /* R/W, 2 bytes */
#define EXT_CSD_DATA_SECTOR_SIZE             61 /* R */
#define EXT_CSD_GP_SIZE_MULT                143 /* R/W */
#define EXT_CSD_PARTITION_SETTING_COMPLETED 155 /* R/W */
#define EXT_CSD_PARTITION_ATTRIBUTE         156 /* R/W */
#define EXT_CSD_MAX_ENH_SIZE_MULT           157 /* RO, 3 bytes */
#define EXT_CSD_PARTITION_SUPPORT           160 /* RO */
#define EXT_CSD_HPI_MGMT                    161 /* R/W */
#define EXT_CSD_RST_N_FUNCTION              162 /* R/W */
#define EXT_CSD_BKOPS_EN                    163 /* R/W */
#define EXT_CSD_BKOPS_START                 164 /* W */
#define EXT_CSD_SANITIZE_START              165 /* W */
#define EXT_CSD_WR_REL_PARAM                166 /* RO */
#define EXT_CSD_RPMB_MULT                   168 /* RO */
#define EXT_CSD_FW_CONFIG                   169 /* R/W */
#define EXT_CSD_BOOT_WP                     173 /* R/W */
#define EXT_CSD_ERASE_GROUP_DEF             175 /* R/W */
#define EXT_CSD_PART_CONFIG                 179 /* R/W */
#define EXT_CSD_ERASED_MEM_CONT             181 /* RO */
#define EXT_CSD_BUS_WIDTH                   183 /* R/W */
#define EXT_CSD_STROBE_SUPPORT              184 /* RO */
#define EXT_CSD_HS_TIMING                   185 /* R/W */
#define EXT_CSD_POWER_CLASS                 187 /* R/W */
#define EXT_CSD_REV                         192 /* RO */
#define EXT_CSD_STRUCTURE                   194 /* RO */
#define EXT_CSD_CARD_TYPE                   196 /* RO */
#define EXT_CSD_DRIVER_STRENGTH             197 /* RO */
#define EXT_CSD_OUT_OF_INTERRUPT_TIME       198 /* RO */
#define EXT_CSD_PART_SWITCH_TIME            199 /* RO */
#define EXT_CSD_PWR_CL_52_195               200 /* RO */
#define EXT_CSD_PWR_CL_26_195               201 /* RO */
#define EXT_CSD_PWR_CL_52_360               202 /* RO */
#define EXT_CSD_PWR_CL_26_360               203 /* RO */
#define EXT_CSD_SEC_CNT                     212 /* RO, 4 bytes */
#define EXT_CSD_S_A_TIMEOUT                 217 /* RO */
#define EXT_CSD_REL_WR_SEC_C                222 /* RO */
#define EXT_CSD_HC_WP_GRP_SIZE              221 /* RO */
#define EXT_CSD_ERASE_TIMEOUT_MULT          223 /* RO */
#define EXT_CSD_HC_ERASE_GRP_SIZE           224 /* RO */
#define EXT_CSD_BOOT_MULT                   226 /* RO */
#define EXT_CSD_SEC_TRIM_MULT               229 /* RO */
#define EXT_CSD_SEC_ERASE_MULT              230 /* RO */
#define EXT_CSD_SEC_FEATURE_SUPPORT         231 /* RO */
#define EXT_CSD_TRIM_MULT                   232 /* RO */
#define EXT_CSD_PWR_CL_200_195              236 /* RO */
#define EXT_CSD_PWR_CL_200_360              237 /* RO */
#define EXT_CSD_PWR_CL_DDR_52_195           238 /* RO */
#define EXT_CSD_PWR_CL_DDR_52_360           239 /* RO */
#define EXT_CSD_BKOPS_STATUS                246 /* RO */
#define EXT_CSD_POWER_OFF_LONG_TIME         247 /* RO */
#define EXT_CSD_GENERIC_CMD6_TIME           248 /* RO */
#define EXT_CSD_CACHE_SIZE                  249 /* RO, 4 bytes */
#define EXT_CSD_PWR_CL_DDR_200_360          253 /* RO */
#define EXT_CSD_FIRMWARE_VERSION            254 /* RO, 8 bytes */
#define EXT_CSD_DEVICE_VERSION              262 /* RO, 2 bytes */
#define EXT_CSD_PRE_EOL_INFO                267 /* RO */
#define EXT_CSD_DEVICE_LIFE_TIME_EST_TYP_A  268 /* RO */
#define EXT_CSD_DEVICE_LIFE_TIME_EST_TYP_B  269 /* RO */
#define EXT_CSD_CMDQ_DEPTH                  307 /* RO */
#define EXT_CSD_CMDQ_SUPPORT                308 /* RO */
#define EXT_CSD_SUPPORTED_MODE              493 /* RO */
#define EXT_CSD_TAG_UNIT_SIZE               498 /* RO */
#define EXT_CSD_DATA_TAG_SUPPORT            499 /* RO */
#define EXT_CSD_MAX_PACKED_WRITES           500 /* RO */
#define EXT_CSD_MAX_PACKED_READS            501 /* RO */
#define EXT_CSD_BKOPS_SUPPORT               502 /* RO */
#define EXT_CSD_HPI_FEATURES                503 /* RO */

/*
 * EXT_CSD field definitions
 */

#define EXT_CSD_WR_REL_PARAM_EN        (1<<2)

#define EXT_CSD_BOOT_WP_B_PWR_WP_DIS   (0x40)
#define EXT_CSD_BOOT_WP_B_PERM_WP_DIS  (0x10)
#define EXT_CSD_BOOT_WP_B_PERM_WP_EN   (0x04)
#define EXT_CSD_BOOT_WP_B_PWR_WP_EN    (0x01)

#define EXT_CSD_PART_CONFIG_ACC_MASK   (0x7)
#define EXT_CSD_PART_CONFIG_ACC_BOOT0  (0x1)
#define EXT_CSD_PART_CONFIG_ACC_RPMB   (0x3)
#define EXT_CSD_PART_CONFIG_ACC_GP0    (0x4)

#define EXT_CSD_PART_SETTING_COMPLETED (0x1)
#define EXT_CSD_PART_SUPPORT_PART_EN   (0x1)

#define EXT_CSD_CMD_SET_NORMAL         (1<<0)
#define EXT_CSD_CMD_SET_SECURE         (1<<1)
#define EXT_CSD_CMD_SET_CPSECURE       (1<<2)

#define EXT_CSD_CARD_TYPE_HS_26        (1<<0) /* Card can run at 26MHz */
#define EXT_CSD_CARD_TYPE_HS_52        (1<<1) /* Card can run at 52MHz */
#define EXT_CSD_CARD_TYPE_HS           (EXT_CSD_CARD_TYPE_HS_26 | EXT_CSD_CARD_TYPE_HS_52)
#define EXT_CSD_CARD_TYPE_DDR_1_8V     (1<<2) /* Card can run at 52MHz */
/* DDR mode @1.8V or 3V I/O */
#define EXT_CSD_CARD_TYPE_DDR_1_2V     (1<<3) /* Card can run at 52MHz */
/* DDR mode @1.2V I/O */
#define EXT_CSD_CARD_TYPE_DDR_52       (EXT_CSD_CARD_TYPE_DDR_1_8V | EXT_CSD_CARD_TYPE_DDR_1_2V)
#define EXT_CSD_CARD_TYPE_HS200_1_8V   (1<<4) /* Card can run at 200MHz */
#define EXT_CSD_CARD_TYPE_HS200_1_2V   (1<<5) /* Card can run at 200MHz */
/* SDR mode @1.2V I/O */
#define EXT_CSD_CARD_TYPE_HS200        (EXT_CSD_CARD_TYPE_HS200_1_8V | EXT_CSD_CARD_TYPE_HS200_1_2V)
#define EXT_CSD_CARD_TYPE_HS400_1_8V   (1<<6) /* Card can run at 200MHz DDR, 1.8V */
#define EXT_CSD_CARD_TYPE_HS400_1_2V   (1<<7) /* Card can run at 200MHz DDR, 1.2V */
#define EXT_CSD_CARD_TYPE_HS400        (EXT_CSD_CARD_TYPE_HS400_1_8V | EXT_CSD_CARD_TYPE_HS400_1_2V)
#define EXT_CSD_CARD_TYPE_HS400ES      (1<<8)    /* Card can run at HS400ES */

#define EXT_CSD_BUS_WIDTH_1            0 /* Card is in 1 bit mode */
#define EXT_CSD_BUS_WIDTH_4            1 /* Card is in 4 bit mode */
#define EXT_CSD_BUS_WIDTH_8            2 /* Card is in 8 bit mode */
#define EXT_CSD_DDR_BUS_WIDTH_4        5 /* Card is in 4 bit DDR mode */
#define EXT_CSD_DDR_BUS_WIDTH_8        6 /* Card is in 8 bit DDR mode */
#define EXT_CSD_BUS_WIDTH_STROBE       (1<<7) /* Enhanced strobe mode */

#define EXT_CSD_TIMING_BC              0 /* Backwards compatility */
#define EXT_CSD_TIMING_HS              1 /* High speed */
#define EXT_CSD_TIMING_HS200           2 /* HS200 */
#define EXT_CSD_TIMING_HS400           3 /* HS400 */
#define EXT_CSD_DRV_STR_SHIFT          4 /* Driver Strength shift */

#define EXT_CSD_SEC_ER_EN              (1<<0)
#define EXT_CSD_SEC_BD_BLK_EN          (1<<2)
#define EXT_CSD_SEC_GB_CL_EN           (1<<4)
#define EXT_CSD_SEC_SANITIZE           (1<<6) /* v4.5 only */

#define EXT_CSD_RST_N_EN_MASK          0x3
#define EXT_CSD_RST_N_ENABLED          1 /* RST_n is enabled on card */

#define EXT_CSD_NO_POWER_NOTIFICATION  0
#define EXT_CSD_POWER_ON               1
#define EXT_CSD_POWER_OFF_SHORT        2
#define EXT_CSD_POWER_OFF_LONG         3

#define EXT_CSD_PWR_CL_8BIT_MASK       0xF0 /* 8 bit PWR CLS */
#define EXT_CSD_PWR_CL_4BIT_MASK       0x0F /* 8 bit PWR CLS */
#define EXT_CSD_PWR_CL_8BIT_SHIFT      4
#define EXT_CSD_PWR_CL_4BIT_SHIFT      0

#define EXT_CSD_PACKED_EVENT_EN        (1<<3)

/*
 * EXCEPTION_EVENT_STATUS field
 */
#define EXT_CSD_URGENT_BKOPS           (1<<0)
#define EXT_CSD_DYNCAP_NEEDED          (1<<1)
#define EXT_CSD_SYSPOOL_EXHAUSTED      (1<<2)
#define EXT_CSD_PACKED_FAILURE         (1<<3)

#define EXT_CSD_PACKED_GENERIC_ERROR   (1<<0)
#define EXT_CSD_PACKED_INDEXED_ERROR   (1<<1)

/*
 * BKOPS status level
 */
#define EXT_CSD_BKOPS_OK               0x0
#define EXT_CSD_BKOPS_NON_CRITICAL     0x1
#define EXT_CSD_BKOPS_PERF_IMPACTED    0x2
#define EXT_CSD_BKOPS_CRITICAL         0x3

/*
 * BKOPS modes
 */
#define EXT_CSD_BKOPS_MANUAL           0x01 /* STICKY! */
#define EXT_CSD_BKOPS_AUTO             0x02

/*
 * Command Queue
 */
#define EXT_CSD_CMDQ_MODE_ENABLED      (1<<0)
#define EXT_CSD_CMDQ_DEPTH_MASK        0x1F
#define EXT_CSD_CMDQ_SUPPORTED         (1<<0)

/*
 * MMC_SWITCH access modes
 */
#define MMC_SWITCH_MODE_CMD_SET        0x00    /* Change the command set */
#define MMC_SWITCH_MODE_SET_BITS       0x01    /* Set bits which are 1 in value */
#define MMC_SWITCH_MODE_CLEAR_BITS     0x02    /* Clear bits which are 1 in value */
#define MMC_SWITCH_MODE_WRITE_BYTE     0x03    /* Set target to value */

/*
 * Erase/trim/discard
 */
#define MMC_ERASE_ARG                  0x00000000
#define MMC_SECURE_ERASE_ARG           0x80000000
#define MMC_TRIM_ARG                   0x00000001
#define MMC_DISCARD_ARG                0x00000003
#define MMC_SECURE_TRIM1_ARG           0x80000001
#define MMC_SECURE_TRIM2_ARG           0x80008000
#define MMC_SECURE_ARGS                0x80000000
#define MMC_TRIM_ARGS                  0x00008001

/*
 * Vendor definitions and structs
 */
#define MMC_SANDISK_HEALTH_REPORT      0x96C9D71C

#endif /* MMC_H */
