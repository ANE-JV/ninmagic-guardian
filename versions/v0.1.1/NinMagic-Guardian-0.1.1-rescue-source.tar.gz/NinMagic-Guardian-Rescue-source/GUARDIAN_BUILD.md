# Build this corresponding source

Install devkitPro devkitARM and GNU Make.

```sh
export DEVKITARM=/path/to/devkitARM
export PATH="$DEVKITARM/bin:$PATH"
make -j4
```

Outputs: output/ninmagic-guardian-rescue.bin and output/libsys_minerva.bso.
This Makefile already contains all Guardian modifications; no patch step is required.
Hardware has not been tested. See GUARDIAN_README.md and LICENSE.
